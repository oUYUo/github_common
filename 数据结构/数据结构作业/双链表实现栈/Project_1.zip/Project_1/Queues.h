#include "head.h"
template <typename Type>
class Queue{
    private:
        /*input your code here*/
    public:
        bool empty() const;
		bool full() const;
        Type top() const;
        void push(Type);
        Type pop();
		void print();
};


template <typename Type>
bool Queue<Type>::empty() const {
	/*input your code here*/
}

template <typename Type>
bool Queue<Type>::full() const {
	/*input your code here*/
}

template <typename Type>
Type Queue<Type>::top() const {
	/*input your code here*/
}

template <typename Type>
void Queue<Type>::push(Type data)  {
	/*input your code here*/
}

template <typename Type>
Type Queue<Type>::pop()  {
	/*input your code here*/
	return 0.0;// ����ʵ��return
}


template <typename Type>
void Queue<Type>::print()  {
	/*input your code here*/
}