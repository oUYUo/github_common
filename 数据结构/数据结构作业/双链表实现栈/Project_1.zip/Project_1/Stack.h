#include "head.h"
template <typename Type>
class Stack {
    private:
        /*input your code here*/
    public:
        bool empty() const;
		bool full() const;
        Type top() const;
        void push( Type);
        Type pop();
		void print();
};
template <typename Type>
bool Stack<Type>::empty() const {
	/*input your code here*/
}

template <typename Type>
bool Stack<Type>::full() const {
	/*input your code here*/
}

template <typename Type>
Type Stack<Type>::top() const {
	/*input your code here*/
}

template <typename Type>
void Stack<Type>::push(Type data)  {
	/*input your code here*/
}

template <typename Type>
Type Stack<Type>::pop()  {
	/*input your code here*/
	return 0.0; // ����ʵ��return
}


template <typename Type>
void Stack<Type>::print()  {
	/*input your code here*/
}